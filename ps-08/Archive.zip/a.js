var ctx = document.getElementById("walk").getContext('2d');

var beginX = 0;
var beginY = 0;

//Clear the screen. 

var clearScreen = function() {
  ctx.fillStyle = "hsla(0,10%,100%,.04)";
  ctx.fillRect(0, 0, 500, 500);
};

//Draw a square on the canvas.

var makePoint = function (x,y) {
    clearScreen();

    ctx.strokeStyle = '';

    var size = 10;
    ctx.fillRect(beginX,beginY,size,size);
    beginX = beginX + 10;

    if (beginX > 500) {
        beginX = 0;
        beginY = beginY + 10;
    };
    if (beginY>500) {
        beginY=0;
    };
    ctx.stroke();
 };


setInterval(makePoint,100);

